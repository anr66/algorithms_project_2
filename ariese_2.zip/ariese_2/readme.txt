To build code:

type "./build.sh" into a linux terminal

This will output an executable called "convexHull"

To run code:

type "convexHull <letter> <data>"
letter is either "G" for Graham Scan, "J" for Jarvis March, or "Q" for Quickhull
data is the path to the data file used for testing
